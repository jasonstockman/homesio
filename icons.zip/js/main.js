$( function() {

	$('.latest').removeClass('hide');
	$('.latest').hide().eq(0).show();

	heroBg();
	setInterval( function() {
		heroBg();
	}, 30000);


	$('#home-search-adv').on('click', function() {
		$('#home-search-more').toggle();
	})

});

function heroBg() {
	$('#hero .wrap img').stop(1,1).css({ left: 0 });
	$('#hero .wrap img').animate({ left: -1367 }, 30000);
}